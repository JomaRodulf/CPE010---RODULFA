#ifndef PLAYLIST_LL_H
#define PLAYLIST_LL_H

#include <iostream>

template <typename T>
class PlaylistNode{
    public:
        T data;
        PlaylistNode<T>* next = nullptr;
};

//NODE CREATION
template <typename T>
PlaylistNode<T>* createNode(T newData){
    PlaylistNode<T>* newNode = new PlaylistNode<T>;
    newNode->data = newData;
    newNode->next = nullptr;
    return newNode;
}

//PLAYLIST CREATION (last points to head)
template <typename T>
PlaylistNode<T>* createPlaylist(T songs[], int size){
    if (songs == nullptr || size <= 0) return nullptr;

    PlaylistNode<T>* head = nullptr;
    for (int i = 0; i < size; i++){
        if (i == 0){
            head = createNode(songs[i]);
            head->next = head;
        } else {
            PlaylistNode<T>* newNode = createNode(songs[i]);
            PlaylistNode<T>* tail = head;
            while (tail->next != head){
                tail = tail->next;
            }
            tail->next = newNode;
            newNode->next = head;
        }
    }
    return head;
}

//TRAVERSAL
template <typename T>
void playlistTraverse(PlaylistNode<T>* head){
    if (head == nullptr){
        std::cout<<"Playlist is empty!"<<std::endl;
        return;
    }

    PlaylistNode<T>* current = head;
    do {
        std::cout<<current->data;
        current = current->next;
        if (current != head){
            std::cout<<" -> ";
        }
    } while (current != head);
    std::cout<<std::endl;
}

//PLAY ALL SONGS
template <typename T>
void playlistPlayAll(PlaylistNode<T>* head){
    std::cout<<"Playing playlist:"<<std::endl;
    playlistTraverse(head);
}

//HEAD INSERTION
template <typename T>
void playlistInsertHead(T newData, PlaylistNode<T>** head){
    PlaylistNode<T>* newNode = createNode(newData);
    if (*head == nullptr){
        *head = newNode;
        newNode->next = newNode;
        return;
    }

    PlaylistNode<T>* tail = *head;
    while (tail->next != *head){
        tail = tail->next;
    }

    newNode->next = *head;
    tail->next = newNode;
    *head = newNode;
}

//END INSERTION
template <typename T>
void playlistInsertEnd(T newData, PlaylistNode<T>** head){
    PlaylistNode<T>* newNode = createNode(newData);
    if (*head == nullptr){
        *head = newNode;
        newNode->next = newNode;
        return;
    }

    PlaylistNode<T>* tail = *head;
    while (tail->next != *head){
        tail = tail->next;
    }

    tail->next = newNode;
    newNode->next = *head;
}

//ANYWHERE INSERTION
template <typename T>
void playlistInsertAfter(T newData, PlaylistNode<T>* prevNode){
    if (prevNode == nullptr){
        std::cout<<"Previous song node cannot be null!"<<std::endl;
        return;
    }

    PlaylistNode<T>* newNode = createNode(newData);
    newNode->next = prevNode->next;
    prevNode->next = newNode;
}

//NEXT SONG
template <typename T>
void playlistNext(PlaylistNode<T>*& current){
    if (current == nullptr) return;
    current = current->next;
}

//PREV SONG
template <typename T>
void playlistPrevious(PlaylistNode<T>* head, PlaylistNode<T>*& current){
    if (head == nullptr || current == nullptr) return;

    PlaylistNode<T>* prev = head;
    while (prev->next != current && prev->next != head){
        prev = prev->next;
    }

    if (prev->next == current){
        current = prev;
    }
}

//NODE DELETION
template <typename T>
void playlistDeleteSong(T findData, PlaylistNode<T>** head){
    if (*head == nullptr) return;

    PlaylistNode<T>* current = *head;
    PlaylistNode<T>* prev = nullptr;
    bool found = false;
    do {
        if (current->data == findData){
            found = true;
            break;
        }
        prev = current;
        current = current->next;
    } while (current != *head);

    if (!found) return;

    if (current->next == current){
        delete current;
        *head = nullptr;
        return;
    }

    if (prev == nullptr){
        // delete head in a multi-node playlist
        PlaylistNode<T>* tail = *head;
        while (tail->next != *head){
            tail = tail->next;
        }
        tail->next = current->next;
        *head = current->next;
        delete current;
        return;
    }

    prev->next = current->next;
    if (current == *head){
        *head = current->next;
    }
    delete current;
}

//LIST DELETION
template <typename T>
void playlistDeleteList(PlaylistNode<T>** head){
    if (*head == nullptr) return;

    PlaylistNode<T>* current = (*head)->next;
    while (current != *head){
        PlaylistNode<T>* temp = current;
        current = current->next;
        delete temp;
    }

    delete *head;
    *head = nullptr;
}

#endif
#ifndef DOUBLE_LL_H
#define DOUBLE_LL_H

template <typename T>
class DoubleList{
    public:
        T data;
        DoubleList<T>* prev = nullptr;
        DoubleList<T>* next = nullptr;
};

template <typename T>
DoubleList<T>* createNode(T newData){
    //Dynamic Memory Allocation
    DoubleList<T> *newNode = new DoubleList<T>;

    newNode->data = newData;
    newNode->prev = nullptr;
    newNode->next = nullptr;

    //Return "newNode" address
    return newNode;
}

//TRAVERSAL
template <typename T>
void dllTraverse(DoubleList<T> *currentNode){

    DoubleList<T> *tail = nullptr;

    //Forward traverse
    std::cout<<"Forward movement: "<<std::endl;
    //CATCHING
    if (currentNode == nullptr){
        std::cout<<"LIST IS EMPTY!"<<std::endl;
    }
    //FORWARD TRAVERSAL
    while (currentNode != nullptr){
        std::cout<<currentNode->data;
        //Last visited node is saved.
        tail = currentNode;
        currentNode = currentNode->next;
    }
    std::cout<<"\n===================\n";
    std::cout<<"\nBackward movement: "<<std::endl;
    if (tail == nullptr){
        std::cout<<"LIST IS EMPTY!"<<std::endl;
    }
    //BACKWARDS TRAVERSAL
    while (tail != nullptr){
        std::cout<<tail->data;
        tail = tail->prev;
    }
    std::cout<<"\n===================\n";
}

//INSERTION======================================
//HEAD INSERTION
template <typename T>
void dllInsertHead(T newData, DoubleList<T>** currentHead){
    //Create a node.
    DoubleList<T>* newNode = createNode(newData);
    //New node points to current head.
    newNode->next = *currentHead;
    //Current node points to new.
    (*currentHead)->prev = newNode;
    //Update header pointer (insert).
    *currentHead = newNode;
}

//END INSERTION
template <typename T>
void dllInsertEnd(T newData, DoubleList<T> *currentHead){
    //create
    DoubleList<T>* newNode = createNode(newData);
    //traverse
    while (currentHead->next != nullptr){
        currentHead = currentHead->next;
    }
    //connect last -> new
    currentHead->next = newNode;
    //connect new -> last
    newNode->prev = currentHead;
}

//GENERAL INSERTION
template <typename T>
void dllMidInsert(T newData, DoubleList<T> *prevNode, DoubleList<T> *currentNode){
    //create
    DoubleList<T>* newNode = createNode(newData);
    //checking
    if (prevNode == nullptr){
        std::cout<<"Previous node cannot be null!"<<std::endl;
        delete newNode;
        return;
    }
    //connect new node between prevNode and currentNode
    newNode->next = currentNode;
    newNode->prev = prevNode;
    prevNode->next = newNode;
    if (currentNode != nullptr){
        currentNode->prev = newNode;
    }
}
//INSERT ANYWHERE
template <typename T>
void ddlInsertAny(T newData, DoubleList<T>* prevNode){
    //checking
    if (prevNode == nullptr) return;
    //create
    DoubleList<T>* newNode = createNode(newData);
    //newNode points to prevNode
    newNode->next = prevNode->next;
    //newNode points to the previous node
    newNode->prev = prevNode;
    //if there is a node after prevNode, points back to newNode
    if (prevNode != nullptr){
        prevNode->next->prev = newNode;
    }
    //prevnode points to new node
    prevNode->next = newNode;
}
//INSERTION=====================================

//NODE DELETION
template <typename T>
void dllDeleteNode(DoubleList<T>** head, DoubleList<T>* delNode){
    if (*head == nullptr || delNode == nullptr) return;

    if (*head == delNode){
        *head = delNode->next;
    }

    if (delNode->next != nullptr){
        delNode->next->prev = delNode->prev;
    }

    if (delNode->prev != nullptr){
        delNode->prev->next = delNode->next;
    }

    delete delNode;
}
//DELETION
template <typename T>
void dllDeleteList(DoubleList<T>** head){
    DoubleList<T>* current = *head;

    while (current != nullptr){
        DoubleList<T>* temp = current;
        current = current->next;
        delete temp;
    }

    *head = nullptr;
}

#endif
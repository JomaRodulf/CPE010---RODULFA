#ifndef SINGLY_LL_H
#define SINGLY_LL_H

#include <iostream>

template <typename T>
class SinglyList{
    public:
        T data;
        SinglyList<T> *next = nullptr;
};

//Traversal
template <typename T>
void listTraversal(SinglyList<T>* head){
    if (head==nullptr){
        std::cout<<"List is empty!"<<std::endl;
        return;
    }
    
    while(head != nullptr){
        std::cout<<head->data;
        if (head->next != nullptr){
            std::cout<<"->";
        }

        head = head->next;
    }
}
//NODE INSERTION (HEAD)
template <typename T>
void sllinsertHead(T newData, SinglyList<T>** currentHead){
    SinglyList<T>* newNode = new SinglyList<T>;
    newNode->data = newData;
    newNode->next = *currentHead;
    *currentHead = newNode;
}

//NODE INSERTION (BODY)
template <typename T>
void sllGeneralInsert(T newData, SinglyList<T>* prevNode){
    if(prevNode == nullptr){
        std::cout<<"Previous node cannot be null!"<<std::endl;
        return;
    }
    SinglyList<T>* newNode = new SinglyList<T>;
    newNode->data = newData;
    newNode->next = prevNode->next;
    prevNode->next = newNode;
}

//NODE INSERTION (END)
template <typename T>
void sllinsertEnd(T newData, SinglyList<T>** head){
    SinglyList<T>* newNode = new SinglyList<T>;
    newNode->data = newData;
    newNode->next = nullptr;

    if (*head == nullptr) {
        *head = newNode;
        return;
    }

    SinglyList<T>* currentNode = *head;
    while(currentNode->next != nullptr){
        currentNode = currentNode->next;
    }

    currentNode->next = newNode;
}
//DELETE NODES
template <typename T>
void sllDeleteNodes(T findData, SinglyList<T>** head){
    if(*head == nullptr) return;

    SinglyList<T>* currNode = *head;
    SinglyList<T>* prevNode = nullptr;

    //SEARCH LOOP
    while(currNode != nullptr && currNode->data != findData){
        prevNode = currNode;
        currNode = currNode->next;
    }

    //findData not found
    if(currNode == nullptr) return;

    //findData is HEAD NODE
    if(prevNode == nullptr){
        *head = currNode->next;
    }else{
        prevNode->next = currNode->next;
    }

    //findData found
    delete currNode;
}

//DELETE ALL NODES
template <typename T>
void sllDeleteList(SinglyList<T>** head){
    SinglyList<T>* current = *head;

    while(current != nullptr){
        SinglyList<T>* temp = current;
        current = current->next;
        
        delete temp;
    }
    
    *head = nullptr;
}
#endif
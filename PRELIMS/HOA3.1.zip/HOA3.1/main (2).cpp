#include "singly_LL.h"
#include <iostream>
#include "doubly__LL.h"
//MAIN FUNCTION----------------------
int main(){

    //Creating empty list:
    SinglyList<char>* head = new SinglyList<char>;
    SinglyList<char>* second = new SinglyList<char>;
    SinglyList<char>* third = new SinglyList<char>;
    SinglyList<char>* fourth = new SinglyList<char>;
    SinglyList<char>* fifth = new SinglyList<char>;
    SinglyList<char>* sixth = new SinglyList<char>;

    //Assign the data(HEAD):
    head->data = 'C';
    head->next = second;

    //Assign the data(SECOND):
    second->data = 'P';
    second->next = third;

    //Assign the data(THIRD):
    third->data = 'E';
    third->next = fourth;

    //Assign the data(FOURTH):
    fourth->data = '0';
    fourth->next = fifth;

    //Assign the data(FIFTH):
    fifth->data = '1';
    fifth->next = sixth;

    //Assign the data(SIXTH):
    sixth->data = '0';
    sixth->next = nullptr;

    listTraversal(head);

    std::cout<<"\nInserting node at the head:\n"<<std::endl;
    SinglyList<char>* newNode = new SinglyList<char>;
    newNode->data = 'G';
    newNode->next = head;
    head = newNode;
    listTraversal(head);
    //INSERT AT BODY
    std::cout<<"\nInserting node at the middle:\n"<<std::endl;
    sllGeneralInsert('E', head->next->next);
    listTraversal(head);
    //INSERT AT END
    std::cout<<"\nInserting node at the end:\n"<<std::endl;
    sllinsertEnd('Z', &head);
    listTraversal(head);
    //END DELETE
    std::cout<<"\nDeleting node = END\n"<<std::endl;
    sllDeleteNodes('Z', &head);
    listTraversal(head);
    //HEAD DELETE
    std::cout<<"\nDeleting node = HEAD\n"<<std::endl;
    sllDeleteNodes('C', &head);
    listTraversal(head);
    //ANYWHERE DELETE
    std::cout<<"\nDeleting node = BODY\n"<<std::endl;
    sllDeleteNodes('P', &head);
    listTraversal(head);
    
    std::cout<<"\nDeleting ALL the lists.\n"<<std::endl;
    sllDeleteList(&head);
    listTraversal(head);

    return 0;
}
#include <iostream>
#include "doubly__LL.h"
//MAIN FUNCTION----------------------
int main(){

    //DOUBLE LIST==============================
    DoubleList<char>* head = createNode('C');
    DoubleList<char>* second = createNode('P');
    DoubleList<char>* third = createNode('E');

    //DOUBLE LIST = NODE LINKING
    head->next = second;
    second->prev = head;
    
    second->next = third;
    third->prev = second;

    //LIST TRAVERSAL
    dllTraverse(head);

    //HEAD INSERT
    std::cout<<"\nHead Insertion (J)."<<std::endl;
    dllInsertHead('J', &head);
    dllTraverse(head);

    //END INSERT
    std::cout<<"\nEnd Insertion (O)."<<std::endl;
    dllInsertEnd('O', head);
    dllTraverse(head);

    //GENERAL INSERT
    std::cout<<"\n General Insertion (M)."<<std::endl;
    dllMidInsert('M', head->next, head->next->next);
    dllTraverse(head);

    //ANYWHERE INSERT
    std::cout<<"\n Anywhere Insertion (A)."<<std::endl;
    DoubleList<char> *current = head;

    while (current != nullptr && current->data != 'P'){
        current = current->next;
    }

    if (current != nullptr){
        ddlInsertAny('A', current);
    }
    dllTraverse(head);

    //DELETE A NODE
    std::cout<<"\nDeleting node 'P' from the list."<<std::endl;
    current = head;
    while (current != nullptr && current->data != 'P'){
        current = current->next;
    }
    if (current != nullptr){
        dllDeleteNode(&head, current);
    }
    dllTraverse(head);

    //DELETE THE LIST
    std::cout<<"\nDeleting entire list."<<std::endl;
    dllDeleteList(&head);
    dllTraverse(head);

    return 0;
}


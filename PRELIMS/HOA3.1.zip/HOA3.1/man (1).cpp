#include <iostream>
#include <string>
#include "playlist__LL.h"

//MAIN FUNCTION----------------------
int main(){

    std::string songs[] = {"Staind - Warm Safe Place", "King Crimson - Epitaph", "Billy Joel - Only the Good Die Young"};
    int songCount = sizeof(songs) / sizeof(songs[0]);
    PlaylistNode<std::string>* playlist = createPlaylist(songs, songCount);

    std::cout<<"Initial playlist:"<<std::endl;
    playlistTraverse(playlist);

    std::cout<<"\nPlay all songs once:"<<std::endl;
    playlistPlayAll(playlist);

    std::cout<<"\nInsert song at the end:"<<std::endl;
    playlistInsertEnd(std::string("Stone Temple Pilots - Creep"), &playlist);
    playlistTraverse(playlist);

    std::cout<<"\nInsert song after 2nd Song:"<<std::endl;
    PlaylistNode<std::string>* current = playlist;
    while (current->data != "King Crimson - Epitaph"){
        current = current->next;
        if (current == playlist) break;
    }
    playlistInsertAfter(std::string("Nakazawa Nobuyoshi - Oh Dear. I'm Alone "), current);
    playlistTraverse(playlist);

    std::cout<<"\nInsert song at the head:"<<std::endl;
    playlistInsertHead(std::string("Whirr - Leave"), &playlist);
    playlistTraverse(playlist);

    current = playlist;
    std::cout<<"\nCurrent song: "<<current->data<<std::endl;
    playlistNext(current);
    std::cout<<"Next song: "<<current->data<<std::endl;
    playlistPrevious(playlist, current);
    std::cout<<"Previous song: "<<current->data<<std::endl;

    std::cout<<"\nRemove 3rd Song:"<<std::endl;
    playlistDeleteSong(std::string("Stone Temple Pilots - Creep"), &playlist);
    playlistTraverse(playlist);

    std::cout<<"\nRemove 1st Song:"<<std::endl;
    playlistDeleteSong(std::string("Whirr - Leave"), &playlist);
    playlistTraverse(playlist);

    std::cout<<"\nDelete entire playlist:"<<std::endl;
    playlistDeleteList(&playlist);
    playlistTraverse(playlist);

    return 0;
}

//Libraries I used
#include <iostream>
#include <string>
using namespace std;

//GroceryList BASE CLASS (uses only GroceryList instead of 2 separate arrays)
class GroceryItem{
protected:
    string itemName;
    int itemPrice;
    int itemCount;

public:
    //Constructor function
    GroceryItem(string productName = "null", int productPrice = 0, int productCount = 0){
        itemName = productName;
        itemPrice = productPrice;
        itemCount = productCount;
        cout << "GROCERY Constructor was called." << endl;
    }

    //Destructor function
    virtual ~GroceryItem(){
        cout << "GROCERY Destructor was called." << endl;
    }

    //Copy Constructor function
    GroceryItem(const GroceryItem &copyItem){
        itemName = copyItem.itemName;
        itemPrice = copyItem.itemPrice;
        itemCount = copyItem.itemCount;
        cout << "GROCERY Copy Constructor was called." << endl;
    }

    //Copy Assignment Operator
    GroceryItem& operator=(const GroceryItem &copyItem){
        if(this != &copyItem){
            itemName = copyItem.itemName;
            itemPrice = copyItem.itemPrice;
            itemCount = copyItem.itemCount;
        }
        return *this;
    }

    //Calculate subtotal
    virtual double calculateSum(){
        return itemPrice * itemCount;
    }

    //Virtual display function
    virtual void display() = 0;
};

//Class & Methods: VEGGIES
class Veggies : public GroceryItem{

public:
    //Constructor function
    Veggies(string productName = "null", int productPrice = 0, int productCount = 0)
        : GroceryItem(productName, productPrice, productCount){

        cout << "VEG Constructor was called." << endl;
    }

    //Destructor function
    ~Veggies(){
        cout << "VEG Destructor was called." << endl;
    }

    //Copy Constructor function
    Veggies(const Veggies &copyVeggies)
        : GroceryItem(copyVeggies){

        cout << "VEG Copy Constructor was called." << endl;
    }

    //Copy Assignment Operator
    Veggies& operator=(const Veggies &copyVeggies){
        GroceryItem::operator=(copyVeggies);
        return *this;
    }

    void display(){
        cout << "Vegetable: " << itemName << endl;
        cout << "Price: PHP " << itemPrice << endl;
        cout << "Quantity: " << itemCount << endl;
        cout << "Subtotal: PHP " << calculateSum() << endl << endl;
    }
};

//Class & Methods: FRUITS
class Fruits : public GroceryItem{

public:
    //Constructor function
    Fruits(string buyingName = "null", int buyingPrice = 0, int buyingCount = 0)
        : GroceryItem(buyingName, buyingPrice, buyingCount){

        cout << "FRUIT Constructor was called." << endl;
    }

    //Destructor function
    ~Fruits(){
        cout << "FRUIT Destructor was called." << endl;
    }

    //Copy Constructor function
    Fruits(const Fruits &copyFruits)
        : GroceryItem(copyFruits){

        cout << "FRUIT Copy Constructor was called." << endl;
    }

    //Copy Assignment Operator
    Fruits& operator=(const Fruits &copyFruits){
        GroceryItem::operator=(copyFruits);
        return *this;
    }

    void display(){
        cout << "Fruit: " << itemName << endl;
        cout << "Price: PHP " << itemPrice << endl;
        cout << "Quantity: " << itemCount << endl;
        cout << "Subtotal: PHP " << calculateSum() << endl << endl;
    }
};

//Function TotalSum
double TotalSum(GroceryItem* GroceryList[], int size){

    double total = 0;

    for(int i = 0; i < size; i++){
        if(GroceryList[i] != nullptr){
            total += GroceryList[i]->calculateSum();
        }
    }

    return total;
}

//MAIN FUNCTION
int main(){

    const int SIZE = 4;

    //GroceryList usage (ONLY ONE ARRAY)
    GroceryItem* GroceryList[SIZE];

    GroceryList[0] = new Fruits("Apple",10,7);
    GroceryList[1] = new Fruits("Banana",10,8);
    GroceryList[2] = new Veggies("Broccoli",60,12);
    GroceryList[3] = new Veggies("Lettuce",50,10);

    cout << "\n===== Jenna's Grocery List =====\n\n";

    for(int i = 0; i < SIZE; i++){
        if(GroceryList[i] != nullptr){
            GroceryList[i]->display();
        }
    }

    cout << "TOTAL = PHP "
         << TotalSum(GroceryList, SIZE)
         << endl;

    //================================
    //DELETE LETTUCE AND DEALLOCATE MEMORY
    cout << "Deleting Lettuce...\n";

    delete GroceryList[3];
    GroceryList[3] = nullptr;
    //================================

    cout << "===== Updated Grocery List (checking) =====\n";

    for(int i = 0; i < SIZE; i++){
        if(GroceryList[i] != nullptr){
            GroceryList[i]->display();
        }
    }

    cout << "New TOTAL = PHP "
         << TotalSum(GroceryList, SIZE)
         << endl;

    //Good practice
    for(int i = 0; i < SIZE; i++){
        if(GroceryList[i] != nullptr){
            delete GroceryList[i];
        }
    }

    return 0;
}
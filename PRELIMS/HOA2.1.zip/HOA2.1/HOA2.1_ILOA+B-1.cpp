//======================Libraries========================
#include <iostream>
#include <string.h>
//=========Class & Function Prototypes===================
class Student{
        private:
            std::string studentName;
            int studentAge;
        public:
            //CONSTRUCTOR!
            Student(std::string newName = "Biggie Cheese", int newAge = 54){
                studentName = newName;
                studentAge = newAge;
                std::cout<<"Constructor called."<<std::endl;
            };
            //DESTRUCTOR!
            ~Student(){
                std::cout<<"Destructor called."<<std::endl;
            }
            //COPY CONSTRUCTOR!
            Student(const Student &copyStudent){
                std::cout<<"Copy constructor called."<<std::endl;
                studentName = copyStudent.studentName;
                studentAge = copyStudent.studentAge;
            }
            //Display attributes
            void printDetail(){ 
                std::cout<<this->studentName<<" "<<this->studentAge<<std::endl;
            }

};

//====================MAIN FUNCTION========================
int main() {

    const size_t j = 5;

    Student studentList[j] = {};
    std::string nameList[j] = {"Carly", "Freddy" , "Sam" , "Zack" , "Cody"};
    int ageList[j] = {15, 16, 18, 19, 16};

    //Final Driver code == Loop A
    for (int i = 0; i < j; i++){
        Student *ptr = new Student(nameList[i], ageList[i]);
        studentList[i] = *ptr;
        //DELETE NEW VARIABLE (single object)
        delete ptr;
        //POINT TO NULL POINTER
        ptr = nullptr;
    }
    //Final Driver code == Loop B
    for (int i = 0; i < j; i++){
        studentList[i].printDetail();
    }
    return 0;
}
//========================================================
 
#include <iostream>
#include <stack>
#include "listStack.h"


int main(){
    std::cout<<"------------------- Pushing 'I' 'E' 'E' 'E' ---------- \n";

    //pushing
    push('I');
    push('E');
    push('E');
    push('E');


    //display top
    Top<char>();

    //display current stack:
    displayALL<char>();

    //popping
    std::cout<<"------------------- Popping 'I' 'E' 'E' 'E' ---------- \n";
    while(!isEmpty<char>()){
        std::cout<<"popping: "<<pop<char>()<<std::endl;

    }

    //display all
    displayALL<char>();

    





    return 0;
}
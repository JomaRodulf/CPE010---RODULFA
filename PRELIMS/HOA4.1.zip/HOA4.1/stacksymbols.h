#ifndef STACKSYMBOLS_H
#define STACKSYMBOLS_H

#include <iostream>
#include <string>
using namespace std;

// Node for linked list stack
struct Node {
    char data;
    Node* next;
};

// Global top pointer
Node* topNode = nullptr;

// Push operation
void push(char c) {
    Node* newNode = new Node();
    newNode->data = c;
    newNode->next = topNode;
    topNode = newNode;
}

// Pop operation
char pop() {
    if (topNode == nullptr) {
        return '\0'; // empty stack
    }
    char val = topNode->data;
    Node* temp = topNode;
    topNode = topNode->next;
    delete temp;
    return val;
}

// Check if stack is empty
bool isEmpty() {
    return topNode == nullptr;
}

// Function to check balanced symbols
bool checkBalanced(const string& expr) {
    for (char c : expr) {
        if (c == '(' || c == '{' || c == '[') {
            push(c);
        } else if (c == ')' || c == '}' || c == ']') {
            if (isEmpty()) return false;
            char top = pop();
            if ((c == ')' && top != '(') ||
                (c == '}' && top != '{') ||
                (c == ']' && top != '[')) {
                return false;
            }
        }
    }
    return isEmpty();
}

#endif


#include "stacksymbols.h"
#include <iostream>

int main() {
    std::string expr;
    std::cout << "Enter an expression: ";
    std::cin >> expr;

    if (checkBalanced(expr)) {
        std::cout << "Expression is balanced!" << std::endl;
    } else {
        std::cout << "Expression is NOT balanced!" << std::endl;
    }

    return 0;
}



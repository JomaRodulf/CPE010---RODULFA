#include <iostream>
#include <stack> //calls the stack from the STL

struct Stack{
    std::string name;
    int quantity;

    Stack(std::string n, int q) : name(n), quantity(q) {
        std::cout<<"Constructed: " << name << "\n";
    }
};


int main(){
    std::stack<int> newStack; //created an object

    //testing the empty() function if its empty
    std::cout<<"Is the stack empty? " << newStack.empty()<<std::endl;

    //inserting 3 elements
    newStack.push(3);
    std::cout<<"Top of stack: " << newStack.top()<<std::endl;
    newStack.push(2);
    std::cout<<"Top of stack: " << newStack.top()<<std::endl;
    newStack.push(1);
    std::cout<<"Top of stack: " << newStack.top()<<std::endl;

    std::cout<<"Is the stack empty?" << newStack.empty()<<std::endl;
    newStack.push(6);
    newStack.push(7);
    newStack.push(8);

    std::cout<<"Size of the stack: " << newStack.size()<<std::endl;

    //swap? -> swap the content of the public member functions
    std::stack<int> swapStack;
    std::stack<int> swapStack2;

    swapStack.push(90);
    swapStack.push(67);

    swapStack2.push(12);

    //swapping
    swapStack.swap(swapStack2);

    //calls
    std::cout<<"Size of the stack after swap: " << swapStack.size()<<std::endl;
    std::cout<<"Size of the stack2 after swap: " << swapStack2.size()<<std::endl;


    //emplace? -> construct and insert element -> public member functions
    std::stack<Stack> itemStack;

    //contructs item
    itemStack.emplace("Shield" , 5);
    itemStack.push(Stack("Sword", 1));

    std::cout<<"Top item: " << itemStack.top().name <<"\n";
    return 0;
}
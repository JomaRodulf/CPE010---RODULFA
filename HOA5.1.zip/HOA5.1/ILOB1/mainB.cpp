#include <iostream>
#include "queueLL.h"

int main(){

    qNode<char> *front = nullptr;
    qNode<char> *back = nullptr;

    //enqueue
    enqueue('J', &front, &back);
    std::cout<<front->data<<" "<<back->data<<std::endl;
    enqueue('O', &front, &back);
    std::cout<<front->data<<" "<<back->data<<std::endl;
    enqueue('M', &front, &back);
    std::cout<<front->data<<" "<<back->data<<std::endl;
    enqueue('A', &front, &back);
    std::cout<<front->data<<" "<<back->data<<std::endl;

    //dequeue
    dequeue(&front, &back);
    std::cout<<front->data<<" "<<back->data<<std::endl;
    //checking for dequeue
    dequeue(&front, &back);
    dequeue(&front, &back);
    dequeue(&front, &back);
    dequeue(&front, &back);

    //queue reinitialization
    enqueue('J', &front, &back);
    std::cout<<front->data<<" "<<back->data<<std::endl;
    enqueue('O', &front, &back);
    std::cout<<front->data<<" "<<back->data<<std::endl;
    enqueue('M', &front, &back);
    std::cout<<front->data<<" "<<back->data<<std::endl;
    enqueue('A', &front, &back);
    std::cout<<front->data<<" "<<back->data<<std::endl;

    //check the front
    checkFront(&front, &back);

    //check the back
    backCheck(&back, &front);

    //displayAll
    displayAll(&front, &back);

    return 0;
}
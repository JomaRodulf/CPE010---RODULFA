#ifndef QUEUELL_H
#define QUEUELL_H

//create class node
template <typename T>
class qNode{
    public:
        T data;
        qNode<T> *next;
};

//class for NEW node
template <typename T>
qNode<T>* new_node(T newData){
    qNode<T>* newNode = new qNode<T>;
    newNode->data = newData;
    newNode->next = nullptr;
    return newNode;
}

//=================================enqueue===============================
template <typename T>
void enqueue(T newData, qNode<T> **frontPtr, qNode<T> **backPtr){
    //create a new node
    qNode<T> *newNode = new_node(newData);

    //insert in empty
    if((*frontPtr)==nullptr && (*backPtr)==nullptr){
        (*frontPtr) = newNode;    //checker if empty +
        (*backPtr) = newNode;     //insert newNode
    }

    //insert in non-empty
    (*backPtr)->next = newNode;  //replace ptr and
    (*backPtr) = newNode;        //replace with newNode

}

//================================dequeue================================
template <typename T>
void dequeue(qNode<T> **frontPtr, qNode<T> **backPtr){
    
    //check if queue is EMPTY
    if((*frontPtr) == nullptr && (*backPtr) == nullptr){
        std::cout<<"The queue is empty!"<<std::endl;
        return;
    }

    //create a temp node
    qNode<T> *deleteNode = nullptr;
    deleteNode = *frontPtr;

    //check if queue has ONLY 1 NODE
    if((*frontPtr)->next == nullptr && (*backPtr)->next == nullptr){
        (*frontPtr) = nullptr;
        (*backPtr) = nullptr;
        delete deleteNode;
        return;
    }

    //delete node
    (*frontPtr) = (*frontPtr)->next;
    deleteNode->next = nullptr;
    delete deleteNode;
}

//================================front=================================
template <typename T>
void checkFront(qNode<T> **frontPtr, qNode<T> **backPtr){
    //checker
    if((*frontPtr) == nullptr && (*backPtr) == nullptr){
        std::cout<<"The queue is empty!"<<std::endl;
        return;
    }
    
    //display the front node
    std::cout<<"The front of the queue is: "<<(*frontPtr)->data<<std::endl;
    return;
}

//================================back==================================
template <typename T>
void backCheck(qNode<T> **backPtr, qNode<T> **frontPtr){
    //checker
    if((*frontPtr) == nullptr && (*backPtr) == nullptr){
        std::cout<<"The queue is empty!"<<std::endl;
        return;
    }

    //display the back node
    std::cout<<"The back of the queue is: "<<(*backPtr)->data<<std::endl;
    return;
}

//============================displayAll================================
template <typename T>
void displayAll(qNode<T> **frontPtr, qNode<T> **backPtr){
    //checker
        if((*frontPtr) == nullptr && (*backPtr) == nullptr){
           std::cout<<"The queue is empty!"<<std::endl;
           return;
        }
        
    //traverse
    std::cout<<"The entire queue is: "<<std::endl;    
    while ((*frontPtr) != nullptr){
        std::cout<<(*frontPtr)->data<<" ";
        (*frontPtr) = (*frontPtr)->next;
    }
    std::cout<<std::endl;
}
#endif
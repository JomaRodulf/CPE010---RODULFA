#include <iostream>
#include "queueArr.h"

int main(){

    //create an object
    arrQueue<int> myQ(5);

    //ENQUEUE
    myQ.Enqueue(10);
    myQ.Enqueue(20);
    myQ.Enqueue(30);
    myQ.Enqueue(40);

    //display
    std::cout<<"=====================================\n";
    std::cout<<"Base Queue:\n";
    myQ.Display();
    std::cout<<"=====================================\n";

    //front
    std::cout<<"The front of the queue is: "
             <<myQ.Front()<<std::endl;
    std::cout<<"=====================================\n";
    
    //empty
    if(myQ.Empty()){
        std::cout<<"The queue is empty!\n";
    }
    else{
        std::cout<<"The queue exists!\n";
    }
    std::cout<<"=====================================\n";

    //size
    std::cout<<"The size of the queue is: "
             <<myQ.Size()<<std::endl;
    std::cout<<"=====================================\n";

    //back
    std::cout<<"The back of the queue is: "
             <<myQ.Back()<<std::endl;
    std::cout<<"=====================================\n";

    //dequeue
    myQ.Dequeue();
    std::cout<<"\nAfter Dequeue:\n";
    myQ.Display();
    std::cout<<"=====================================\n";

    //enqueue
    myQ.Enqueue(50);
    std::cout<<"\nAfter Enqueue (50):\n";
    myQ.Display();
    std::cout<<"=====================================\n";

    //clear
    myQ.Clear();
    std::cout<<"\nAfter Clear:\n";
    myQ.Display();
    std::cout<<"=====================================\n";

    //copy constructor
    arrQueue<int> Q2;
    std::cout<<"Copying Queue (enqueue 100 and 200):\n";
    Q2.Enqueue(100);
    Q2.Enqueue(200);
    std::cout<<"=====================================\n";

    arrQueue<int> Q3(Q2);

    std::cout<<"\nCopied Queue:\n";
    Q3.Display();
    std::cout<<"=====================================\n";

    //assignment operator
    arrQueue<int> Q4;
    Q4 = Q2;

    std::cout<<"\nAssigned Queue:\n";
    Q4.Display();
    std::cout<<"=====================================\n";

    return 0;
}

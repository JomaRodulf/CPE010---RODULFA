#ifndef QUEUEARR_H
#define QUEUEARR_H
#include <iostream>
//=============================QUEUE USING ARRAY=============================
template <typename T>
class arrQueue{
private:
    //DATA MEMBERS
    T* q_array;
    int q_capacity;
    int q_size;
    int q_front;
    int q_back;

public:

    //CONSTRUCTOR
    arrQueue(int capacity = 10){
        q_capacity = capacity;
        q_array = new T[q_capacity];

        q_size = 0;
        q_front = 0;
        q_back = -1;
    }

    //COPY CONSTRUCTOR
    arrQueue(const arrQueue& other){
        q_capacity = other.q_capacity;
        q_size = other.q_size;
        q_front = other.q_front;
        q_back = other.q_back;

        q_array = new T [q_capacity];

        for(int i = 0; i < q_capacity; i++){
            q_array[i] = other.q_array[i];
        }
    }

    //COPY ASSIGNMENT OPERATOR
    arrQueue& operator=(const arrQueue& other){

        if(this != &other){

            delete[] q_array;

            q_capacity = other.q_capacity;
            q_size = other.q_size;
            q_front = other.q_front;
            q_back = other.q_back;

            q_array = new T[q_capacity];

            for(int i = 0; i < q_capacity; i++){
                q_array[i] = other.q_array[i];
            }
        }

        return *this;
    }

    //DESTRUCTOR
    ~arrQueue(){
        delete[] q_array;
    }

    //=============================FUNCTIONS=============================

    //EMPTY
    bool Empty() const{
        return q_size == 0;
    }

    //SIZE
    int Size() const{
        return q_size;
    }

    //CLEAR
    void Clear(){
        q_size = 0;
        q_front = 0;
        q_back = -1;
    }

    //FRONT
    int Front() const{

        if(Empty()){
            throw std::out_of_range("Queue is empty.");
        }

        return q_array[q_front];
    }

    //BACK
    int Back() const{

        if(Empty()){
            throw std::out_of_range("Queue is empty.");
        }

        return q_array[q_back];
    }

    //ENQUEUE
    void Enqueue(T value){

        if(q_size == q_capacity){
            std::cout<<"Queue Overflow!\n";
            return;
        }

        q_back = (q_back + 1) % q_capacity;
        q_array[q_back] = value;
        q_size++;
    }

    //DEQUEUE
    void Dequeue(){

        if(Empty()){
            std::cout<<"Queue Underflow!\n";
            return;
        }

        q_front = (q_front + 1) % q_capacity;
        q_size--;
    }

    //DISPLAY
    void Display() const{

        if(Empty()){
            std::cout<<"Queue is empty.\n";
            return;
        }

        for(int i = 0; i < q_size; i++){
            std::cout<<q_array[(q_front + i) % q_capacity]<<" ";
        }

        std::cout<<std::endl;
    }
};

#endif
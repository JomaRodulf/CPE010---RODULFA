#include <iostream>
#include <queue>
//PROTOTYPE
void display(std::queue<char> copyQ);

int main(){
    //create an object
    std::queue<char> myQ;

    //PUSHING
    myQ.push('J');
    myQ.push('O');
    myQ.push('M');
    myQ.push('A');

    //displayAll
    std::cout<<"======================================\n";
    std::cout<<"Base Queue: "<<std::endl;
    display(myQ);
    std::cout<<"======================================\n";

    //trying all member functions
//================================================================
    //front
    std::cout<<"The front of the queue is: "<< myQ.front() <<std::endl;;

    //empty
    if (myQ.empty()){
        std::cout<<"The queue is empty!"<<std::endl;
    }else{
        std::cout<<"The queue exists!\n";
    }
    
    //size
    std::cout<<"The size of the queue is: "<<myQ.size()<<std::endl;

    //back
    std::cout<<"The back of the queue is: "<< myQ.back() <<std::endl;

    //popping
    myQ.pop();
    std::cout<<"New popped queue: "<<std::endl;
    display(myQ);

    //push
    myQ.push('M');
    std::cout<<"Pushed M to the end of the queue!\n";
    display(myQ);

    return 0;
}
//display def
void display(std::queue<char> copyQ){
    std::queue<char> c = copyQ;    //placement queue

    while(!c.empty()){
        std::cout<<" "<<c.front();
        c.pop();
    }
    std::cout<<"\n";
}

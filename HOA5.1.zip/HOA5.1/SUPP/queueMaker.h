#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>
#include <stdexcept>

template <typename T>

class queueMaker{

private:

    //DATA MEMBERS
    T* q_array;

    int q_capacity;
    int q_size;
    int q_front;
    int q_back;

public:

    //CONSTRUCTOR
    queueMaker(int capacity = 10){

        q_capacity = capacity;
        q_array = new T[q_capacity];

        q_size = 0;
        q_front = 0;
        q_back = -1;
    }

    //COPY CONSTRUCTOR
    queueMaker(const queueMaker& other){

        q_capacity = other.q_capacity;
        q_size = other.q_size;
        q_front = other.q_front;
        q_back = other.q_back;

        q_array = new T[q_capacity];

        for(int i=0;i<q_capacity;i++){
            q_array[i] = other.q_array[i];
        }
    }

    //COPY ASSIGNMENT
    queueMaker& operator=(const queueMaker& other){

        if(this != &other){

            delete[] q_array;

            q_capacity = other.q_capacity;
            q_size = other.q_size;
            q_front = other.q_front;
            q_back = other.q_back;

            q_array = new T[q_capacity];

            for(int i=0;i<q_capacity;i++){
                q_array[i] = other.q_array[i];
            }
        }

        return *this;
    }

    //DESTRUCTOR
    ~queueMaker(){

        delete[] q_array;
    }

    //====================================FUNCTIONS====================================

    //EMPTY
    bool empty() const{

        return q_size == 0;
    }

    //SIZE
    int size() const noexcept {
        return q_size;
    }

    //CLEAR
    void clear(){

        q_size = 0;
        q_front = 0;
        q_back = -1;
    }

    //FRONT
    T front() const{

        if(empty()){
            throw std::out_of_range("Queue is empty.");
        }

        return q_array[q_front];
    }

    //BACK
    T back() const{

        if(empty()){
            throw std::out_of_range("Queue is empty.");
        }

        return q_array[q_back];
    }

    //ENQUEUE
    void enqueue(const T& value){

        if(q_size == q_capacity){

            std::cout<<"Queue Overflow!\n";
            return;
        }

        q_back = (q_back + 1) % q_capacity;

        q_array[q_back] = value;

        q_size++;
    }

    //DEQUEUE
    void dequeue(){

        if(empty()){

            std::cout<<"Queue Underflow!\n";
            return;
        }

        q_front = (q_front + 1) % q_capacity;

        q_size--;
    }

};

#endif
#include <iostream>
#include "printer.h"

int main(){

    //create printer
    Printer officePrinter(10);

    //adding jobs
    officePrinter.addJob(jobList(101,"Joma", 8));
    officePrinter.addJob(jobList(102,"Niña", 12));
    officePrinter.addJob(jobList(103,"Fenzie", 9));
    officePrinter.addJob(jobList(104,"Ella", 18));
    officePrinter.addJob(jobList(105,"Rodney", 2));

    std::cout<<"\n====================================\n";
    std::cout<<"Processing Printer Queue...\n";
    std::cout<<"====================================\n";

    officePrinter.processAllJobs();

    return 0;
}
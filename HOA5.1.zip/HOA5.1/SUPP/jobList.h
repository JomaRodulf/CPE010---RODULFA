#ifndef JOBLIST_H
#define JOBLIST_H

#include <iostream>

class jobList{

private:

    int jobID;
    std::string userName;
    int pages;

public:

    //CONSTRUCTOR
    jobList(){

        jobID = 0;
        userName = "";
        pages = 0;
    }

    //PARAMETERIZED CONSTRUCTOR
    jobList(int id, std::string user, int p){

        jobID = id;
        userName = user;
        pages = p;
    }

    //GETTERS
    int getID() const{

        return jobID;
    }

    std::string getUser() const{

        return userName;
    }

    int getPages() const{

        return pages;
    }

};

#endif
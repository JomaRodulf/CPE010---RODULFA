#ifndef PRINTER_H
#define PRINTER_H

#include <iostream>

#include "queueMaker.h"
#include "jobList.h"

class Printer {

private:

    //QUEUE OF PRINT JOBS
    queueMaker<jobList> jobs;

public:

    //CONSTRUCTOR
    Printer(int capacity = 10) {
        (void)capacity;
    }

    //ADD JOB
    void addJob(const jobList& newJob) {
        jobs.enqueue(newJob);
        std::cout << "Job Added Successfully!\n";
    }

    //PROCESS ONE JOB
    void processJob() {
        if (jobs.empty()) {
            std::cout << "No jobs to process.\n";
            return;
        }

        jobList current = jobs.front();

        std::cout << "\n===================================\n";
        std::cout << "Printing Job...\n";
        std::cout << "Job ID : " << current.getID() << std::endl;
        std::cout << "User   : " << current.getUser() << std::endl;
        std::cout << "Pages  : " << current.getPages() << std::endl;
        std::cout << "Printing Complete!\n";
        std::cout << "===================================\n";

        jobs.dequeue();
    }

    //PROCESS ALL JOBS
    void processAllJobs() {
        while (!jobs.empty()) {
            processJob();
        }
    }
};

#endif
#include <iostream>
#include <vector>
#include <iomanip>

struct adjNode
{
    int val, cost;
    adjNode* next;
};

struct graphEdge
{
    int start_ver;
    int end_ver;
    int weight;
};

class GraphMatrix
{
private:
    int numVertices;
    std::vector<std::vector<int>> adjMatrix;

public:
    GraphMatrix(int N) : numVertices(N), adjMatrix(N, std::vector<int>(N, 0)) {}

    void addEdge(int start, int end, int weight)
    {
        if (start >= 0 && start < numVertices && end >= 0 && end < numVertices)
        {
            adjMatrix[start][end] = weight;
        }
    }

    void displayMatrix()
    {
        std::cout << "--- ADJACENCY MATRIX ---\n";
        std::cout << "   ";
        for (int i = 0; i < numVertices; ++i)
        {
            std::cout << std::setw(3) << i;
        }
        std::cout << "\n";

        for (int i = 0; i < numVertices; ++i)
        {
            std::cout << std::setw(2) << i << " ";
            for (int j = 0; j < numVertices; ++j)
            {
                std::cout << std::setw(3) << adjMatrix[i][j];
            }
            std::cout << "\n";
        }
        std::cout << std::endl;
    }
};

class DiaGraph
{
private:
    adjNode* getAdjListNode(int value, int weight, adjNode* head)
    {
        adjNode* newNode = new adjNode;
        newNode->val = value;
        newNode->cost = weight;
        newNode->next = head;
        return newNode;
    }

    int N;

public:
    adjNode** head;

    DiaGraph(graphEdge edges[], int n, int N)
    {
        head = new adjNode*[N]();
        this->N = N;

        for (int i = 0; i < N; i++)
        {
            head[i] = nullptr;
        }

        for (int i = 0; i < n; i++)
        {
            int start_ver = edges[i].start_ver;
            int end_ver = edges[i].end_ver;
            int weight = edges[i].weight;

            adjNode* newNode = getAdjListNode(end_ver, weight, head[start_ver]);
            head[start_ver] = newNode;
        }
    }

    ~DiaGraph()
    {
        for (int i = 0; i < N; i++)
        {
            adjNode* current = head[i];
            while (current != nullptr)
            {
                adjNode* temp = current;
                current = current->next;
                delete temp;
            }
        }
        delete[] head;
    }
};

void display_AdjList(adjNode* ptr, int i)
{
    while (ptr != nullptr)
    {
        std::cout << "(" << i << ", " << ptr->val << ", " << ptr->cost << ") ";
        ptr = ptr->next;
    }
    std::cout << std::endl;
}

int main()
{
    graphEdge edges[] = {
        {0, 1, 2},
        {0, 2, 4},
        {1, 4, 3},
        {2, 3, 2},
        {3, 1, 4},
        {4, 3, 3}
    };

    int N = 6;
    int n = sizeof(edges) / sizeof(edges[0]);

    GraphMatrix matrixGraph(N);
    for (int i = 0; i < n; ++i)
    {
        matrixGraph.addEdge(edges[i].start_ver, edges[i].end_ver, edges[i].weight);
    }
    matrixGraph.displayMatrix();

    DiaGraph listGraph(edges, n, N);
    std::cout << "--- ADJACENCY LIST ---" << std::endl;
    std::cout << "(Start Vertex, End Vertex, Weight)" << std::endl;
    for (int i = 0; i < N; i++)
    {
        display_AdjList(listGraph.head[i], i);
    }

    return 0;
}
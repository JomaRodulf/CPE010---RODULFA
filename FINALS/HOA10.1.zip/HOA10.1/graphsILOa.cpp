#include <iostream>

//adjacency list items
struct adjNode{
    int val, cost;
    adjNode* next;
};

//structure
struct graphEdge{
    int start_ver;
    int end_ver;
    int weight;
};

//directed graph class
class diaGraph{
    private:
        adjNode* getAdjListNode(int value, int weight, adjNode* head){
        adjNode* newNode = new adjNode;

        newNode->val = value;
        newNode->cost = weight;
        newNode->next = head;

        return newNode;
    }

    int N;

    public:
        adjNode** head;

        diaGraph(graphEdge edges[], int n, int N){
        head = new adjNode*[N]();
        this->N = N;

        for (int i = 0; i < N; i++){
            head[i] = nullptr;
        }

        for (int i = 0; i < n; i++){
            int start_ver = edges[i].start_ver;
            int end_ver = edges[i].end_ver;
            int weight = edges[i].weight;

            adjNode* newNode =
                getAdjListNode(end_ver, weight, head[start_ver]);

            head[start_ver] = newNode;
        }
    }
    //destructor
    ~diaGraph(){
        delete[] head;
    }
};

//display adjacency list
void display_AdjList(adjNode* ptr, int i){
    while (ptr != nullptr){
        std::cout << "("
                  << i << ", "
                  << ptr->val << ", "
                  << ptr->cost << ") ";

        ptr = ptr->next;
    }

    std::cout << std::endl;
}

int main(){
    graphEdge edges[] ={{0,1,2}, {0,2,4}, {1,4,3}, {2,3,2}, {3,1,4}, {4,3,3} };

    int N = 6;
    int n = sizeof(edges) / sizeof(edges[0]);

    diaGraph diagraph(edges, n, N);

    std::cout << "(Start Vertex, End Vertex, Weight)" << std::endl;

    for (int i = 0; i < N; i++)
    {
        display_AdjList(diagraph.head[i], i);
    }

    return 0;
}
#include <iostream>
#include "BST.h"

int main(){

    //root node
    BinarySearchTree<int>* tree = new BinarySearchTree(2);

    //insert test
    tree->insert(3);
    tree->insert(9);

    //occupied insertion testing
    tree->insert(18);
    tree->insert(0);
    tree->insert(1);
    tree->insert(4);
    tree->insert(5);

    //preorder search
    std::cout<<"Preorder output: ";
    tree->preOrder();
    std::cout<<std::endl;

    //inorder search
    std::cout<<"Inorder output: ";
    tree->inOrder();
    std::cout<<std::endl;

    //postorder search
    std::cout<<"Postorder output: ";
    tree->postOrder();
    std::cout<<std::endl;
    
    return 0;                                                        
}
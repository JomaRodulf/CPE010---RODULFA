#ifndef BST_H
#define BST_H

//Binary Search Tree : CLASS TEMPLATE
template <typename T>
class BinarySearchTree{
    private:
        T key;
        BinarySearchTree<T>* left;
        BinarySearchTree<T>* right;

    public:
        //constructor
        BinarySearchTree(T value);

        //insertion
        void insert(T value);

        //preOrder
        void preOrder(); //ROOT - LEFT - RIGHT

        //inOrder
        void inOrder(); //LEFT - ROOT - RIGHT

        //postOrder
        void postOrder(); //LEFT - RIGHT - ROOT
};

//constructor def
template <typename T>
BinarySearchTree<T>::BinarySearchTree(T value){
    key = value;
    left = nullptr;
    right = nullptr;
}

//insertion def
template <typename T>
void BinarySearchTree<T>::insert(T value){
    //if < key, go left
    if (value < key){
        //EMPTY
        if (left == nullptr){
            left = new BinarySearchTree(value);
        }
        //OCCUPIED
        else{
            left->insert(value); //recursive
        }
    }

    //if > key, go right
    else if (value > key){
        //EMPTY
        if (right == nullptr){
            right = new BinarySearchTree(value);
        }
        //OCCUPIED
        else{
            right->insert(value); //recursive
        }
    }
}

//preOrder def
template <typename T>
void BinarySearchTree<T>::preOrder(){
    //print current key
    std::cout<< key << " ";
    
    //visit the left
    if (left != nullptr){
        left->preOrder();
    }
    
    //visit the right
    if (right != nullptr){
        right->preOrder();
    }
}

//inOrder def
template <typename T>
void BinarySearchTree<T>::inOrder(){
    //get to left IMMEDIATELY
    if (left != nullptr){
        left->inOrder();
    }

    //print current key
    std::cout<< key << " ";
    
    //visit the right
    if (right != nullptr){
        right->inOrder();
    }
}

//postOrder def
template <typename T>
void BinarySearchTree<T>::postOrder(){
    //check the right
    if (left != nullptr){
        left->postOrder();
    }
    
    //check the right
    if (right != nullptr){
        right->postOrder();
    }

    //print current key
    std::cout<< key << " ";
}
#endif
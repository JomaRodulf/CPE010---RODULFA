#include <iostream>
#include "BST.h"

int main()
{
    //---------I.L.O. A---------
    BinarySearchTree<char>* tree =
    new BinarySearchTree<char>('A');

    tree->insert('B');
    tree->insert('C');
    tree->insert('D');
    tree->insert('E');
    tree->insert('F');
    tree->insert('G');
    //--------------------------

    //======I.L.O. B (3.4)======
    tree->insert('O');

    tree->insert('H');
    tree->insert('I');
    tree->insert('J');
    tree->insert('K');
    tree->insert('L');
    tree->insert('M');
    tree->insert('N');
    tree->insert('P');
    tree->insert('Q');
    //==========================

    //preorder search
    std::cout<<"Preorder output: ";
    tree->preOrder();
    std::cout<<std::endl;

    //inorder search
    std::cout<<"Inorder output: ";
    tree->inOrder();
    std::cout<<std::endl;

    //postorder search
    std::cout<<"Postorder output: ";
    tree->postOrder();
    std::cout<<std::endl;

    //finddata
    std::cout<<"\nFinding Q" << std::endl;
    tree->findData('Q');

    std::cout<<"\nFinding O" << std::endl;
    tree->findData('O');

    return 0;
}
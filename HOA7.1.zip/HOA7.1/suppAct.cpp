#include <iostream>
#include <cstdlib>
#include <time.h>
#include "sorting.h"

const int max_size = 101;

int main (){
    int testArray[max_size];

    srand(time(0)); //Seed the random number generator

    for (int i = 0; i < max_size; i++) {    
        testArray[i] = std::rand() % 5 + 1; //Values represent candidates 1 to 5
    }

    //DISPLAYING THE ARRAY
    std::cout<<"Array elements:\n";
    displayArray(testArray, max_size);

    //SORTING THE VOTES
    std::cout<<"\n\nSorting the votes using Insertion Sort...\n";
    InsertionSort(testArray, max_size);
    displayArray(testArray, max_size);

    int winningCandidate = 1;
    int highestVotes = 0;

    //SEARCHING FOR EACH CANDIDATE'S VOTES
    std::cout<<"\n\nVote count:\n";
    for (int candidate = 1; candidate <= 5; candidate++) {
        int votes = CountVotes(testArray, max_size, candidate);
        std::cout << "Candidate " << candidate << ": " << votes << " votes\n";

        if (votes > highestVotes) {
            highestVotes = votes;
            winningCandidate = candidate;
        }
    }

    std::cout << "\nWinning candidate: Candidate " << winningCandidate;
    std::cout << " with " << highestVotes << " votes\n";

    return 0;
}
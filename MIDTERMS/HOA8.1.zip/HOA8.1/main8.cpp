#include <iostream>
#include <cstdlib>
#include <time.h>
#include "sorthings.h"

const int max_size = 100;

int main (){
    int testArray[max_size];
    int shellArray[max_size];
    int mergeArray[max_size];
    int quickArray[max_size];

    srand(time(0)); //Seed the random number generator

    //Fills array with 100 random numbers
    for (int i = 0; i < max_size; i++) {
        testArray[i] = std::rand() % 100 + 1; //std::rand = random number gen
    }

    //COPYING THE ORIGINAL ARRAY
    for (int i = 0; i < max_size; i++) {
        shellArray[i] = testArray[i];
        mergeArray[i] = testArray[i];
        quickArray[i] = testArray[i];
    }


    //DISPLAYING THE ARRAY
    std::cout<<"Array elements:\n";
    displayArray(testArray, max_size);


    //SHELL SORT
    std::cout<<"\n\nSorting the array using Shell Sort...\n";
    ShellSort(shellArray, max_size);
    displayArray(shellArray, max_size);


    //MERGE SORT
    std::cout<<"\n\nSorting the array using Merge Sort...\n";
    MergeSort(mergeArray, 0, max_size - 1);
    displayArray(mergeArray, max_size);


    //QUICK SORT
    std::cout<<"\n\nSorting the array using Quick Sort...\n";
    QuickSort(quickArray, 0, max_size - 1);
    displayArray(quickArray, max_size);


    return 0;
}
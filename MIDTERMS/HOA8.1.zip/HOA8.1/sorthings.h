#ifndef SORTHINGs_H
#define SORTHINGs_H

#include <iostream>

//DISPLAYING ALL ARRAY ELEMENTS
void displayArray(const int values[], int maxSize) {
    for (int i = 0; i < maxSize; i++) {
        std::cout << values[i] << ' ';

        if ((i + 1) % 10 == 0) {
            std::cout << "";
        }
    }
}


//bubble sorting
template <typename T>
void BubbleSort (T arr[], int maxSize) {
    for (int i = 0; i < maxSize - 1; i++) {
        for (int j = 0; j < maxSize - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                std::swap(arr[j], arr[j + 1]);
            }
        }
    }
}


//selection sorting
template <typename T>
int routine_smallest (T arr[], int k, int maxSize) {
    int position = k;
    T smallestElement = arr[k]; //smallest element = first element

    //if j (current) is smaller than k, set the position to j and current smallest element to j
    for (int j = k + 1; j < maxSize; j++) {
        if (arr[j] < smallestElement) {
            smallestElement = arr[j];
            position = j;
        }
    }

    return position;
}

template <typename T>
void SelectionSort (T arr[], int maxSize) {
    int minVal;

    for (int i = 0; i < maxSize - 1; i++) {
        minVal = routine_smallest(arr, i, maxSize);
        std::swap(arr[i], arr[minVal]);
    }
}


//insertion sorting
template <typename T>
void InsertionSort (T arr[], int maxSize) {
    int k = 1, j;
    T temp; //swapping, cannot use std::swap

    while (k < maxSize) {
        temp = arr[k];
        j = k - 1;

        while (j >= 0 && temp <= arr[j]){
            arr[j + 1] = arr[j];
            j--; //backtracking part
        }

        //reassigning values and moving to next element
        arr[j + 1] = temp;
        k++;
    }
}

//+-+-+-+-+-+-+-+-+-+-+-+-+-+-HOA 8.1-+-+-+-+-+-+-+-+-+-+-+-+-+-+
//=======================SHELL SORT=========================
//shell sorting
template <typename T>
void ShellSort (T arr[], int maxSize) {
    //Start with a large gap and reduce the gap
    for (int gap = maxSize / 2; gap > 0; gap /= 2) {

        //Perform insertion sort using the current gap
        for (int i = gap; i < maxSize; i++) {
            T temp = arr[i];
            int j = i;

            while (j >= gap && arr[j - gap] > temp) {
                arr[j] = arr[j - gap];
                j -= gap;
            }

            arr[j] = temp;
        }
    }
}


//=======================MERGE SORT=========================
//merge two sorted portions of the array
template <typename T>
void Merge (T arr[], int left, int middle, int right) {
    int leftSize = middle - left + 1;
    int rightSize = right - middle;

    T leftArray[leftSize];
    T rightArray[rightSize];

    //copy values to the left array
    for (int i = 0; i < leftSize; i++) {
        leftArray[i] = arr[left + i];
    }

    //copy values to the right array
    for (int i = 0; i < rightSize; i++) {
        rightArray[i] = arr[middle + 1 + i];
    }

    int i = 0;
    int j = 0;
    int k = left;

    //merge the two arrays in sorted order
    while (i < leftSize && j < rightSize) {
        if (leftArray[i] <= rightArray[j]) {
            arr[k] = leftArray[i];
            i++;
        }
        else {
            arr[k] = rightArray[j];
            j++;
        }

        k++;
    }

    //copy remaining values from left array
    while (i < leftSize) {
        arr[k] = leftArray[i];
        i++;
        k++;
    }

    //copy remaining values from right array
    while (j < rightSize) {
        arr[k] = rightArray[j];
        j++;
        k++;
    }
}


//merge sorting
template <typename T>
void MergeSort (T arr[], int left, int right) {
    if (left < right) {
        int middle = left + (right - left) / 2;

        //sort the left half
        MergeSort(arr, left, middle);

        //sort the right half
        MergeSort(arr, middle + 1, right);

        //merge both sorted halves
        Merge(arr, left, middle, right);
    }
}


//=======================QUICK SORT=========================
//partition the array around the pivot
template <typename T>
int Partition (T arr[], int low, int high) {
    T pivot = arr[high];
    int i = low - 1;

    //move elements smaller than pivot to the left
    for (int j = low; j < high; j++) {
        if (arr[j] < pivot) {
            i++;
            std::swap(arr[i], arr[j]);
        }
    }

    //place pivot in its proper position
    std::swap(arr[i + 1], arr[high]);

    return i + 1;
}


//quick sorting
template <typename T>
void QuickSort (T arr[], int low, int high) {
    if (low < high) {
        int pivot = Partition(arr, low, high);

        //sort the left sub list
        QuickSort(arr, low, pivot - 1);

        //sort the right sub list
        QuickSort(arr, pivot + 1, high);
    }
}
//+-+-+-+-+-+-+-+-+-+-+-+-+-+-HOA 8.1-+-+-+-+-+-+-+-+-+-+-+-+-+-+

//=======================SUPPLEMENTARY=========================
//searching for the number of votes for a candidate
template <typename T>
int CountVotes (const T arr[], int maxSize, T candidate) {
    int votes = 0;

    for (int i = 0; i < maxSize; i++) {
        if (arr[i] == candidate) {
            votes++;
        }
    }

    return votes;
}

#endif
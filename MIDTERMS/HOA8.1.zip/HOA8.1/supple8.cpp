#include <iostream>
#include <cstdlib>
#include <time.h>
#include "sorthings.h"

const int max_size = 15;

int main (){
    int testArray[max_size] = {4, 34, 29, 48, 53, 87, 12, 30, 44, 25, 93, 67, 43, 19, 74};

    int shellArray[max_size];
    int mergeArray[max_size];
    int quickArray[max_size];

    //COPYING THE ORIGINAL ARRAY
    for (int i = 0; i < max_size; i++) {
        shellArray[i] = testArray[i];
        mergeArray[i] = testArray[i];
        quickArray[i] = testArray[i];
    }


    //DISPLAYING THE ORIGINAL ARRAY
    std::cout<<"Original array:\n";
    displayArray(testArray, max_size);


    //SHELL SORT
    std::cout<<"\n\nSorting using Shell Sort...\n";
    ShellSort(shellArray, max_size);
    displayArray(shellArray, max_size);


    //MERGE SORT
    std::cout<<"\n\nSorting using Merge Sort...\n";
    MergeSort(mergeArray, 0, max_size - 1);
    displayArray(mergeArray, max_size);


    //QUICK SORT
    std::cout<<"\n\nSorting using Quick Sort...\n";
    QuickSort(quickArray, 0, max_size - 1);
    displayArray(quickArray, max_size);


    return 0;
}
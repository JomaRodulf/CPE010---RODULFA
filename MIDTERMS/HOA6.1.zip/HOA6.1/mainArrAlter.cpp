#include <iostream>
#include "queueArr_alter.h"

int main(){

    //create an object
    QueueArr<char> q(6);

    q.Enqueue('J');
    std::cout<<"Front: "<<q.Front('J')<<" "<<"Back: "<<q.Back()<<std::endl;
    q.Enqueue('O');
    std::cout<<"Front: "<<q.Front('O')<<" "<<"Back: "<<q.Back()<<std::endl;
    q.Enqueue('M');
    std::cout<<"Front: "<<q.Front('M')<<" "<<"Back: "<<q.Back()<<std::endl;
    q.Enqueue('A');
    std::cout<<"Front: "<<q.Front('A')<<" "<<"Back: "<<q.Back()<<std::endl;

    return 0;
}